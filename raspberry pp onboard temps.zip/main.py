from machine import Pin, ADC
import utime

temps= machine.ADC(4)
conversion_factor = 3.3/65535


while True:
    data = temps.read_u16() * conversion_factor
    print(data)
    celsius= 27-(data-0.706)* 0.001721
    print(celsius)
    utime.sleep(1)
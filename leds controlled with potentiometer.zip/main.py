from machine import Pin, PWM, ADC
import utime


ledr= PWM(Pin(15))
ledb= PWM(Pin(12))
ledg= PWM(Pin(10))
ledwhite = PWM(Pin(13))

adc =ADC(Pin(26)) 






while True:
    duty = adc.read_u16()
    ledwhite.duty_u16(duty)
    if duty<20000:
        ledb.duty_u16(60000)
        ledg.duty_u16(0)
        ledr.duty_u16(0)

    elif 20000<=duty<40000:
        ledg.duty_u16(60000)
        ledb.duty_u16(0)
        ledr.duty_u16(0)
    
    elif duty>=40000:
        ledr.duty_u16(60000)
        ledb.duty_u16(0)
        ledg.duty_u16(0)







from machine import Pin
import utime

led_r= Pin(13,Pin.OUT)



while True:
    
    led_r.value(1)
    utime.sleep(1)
    led_r.value(0)
    utime.sleep(1)


    

